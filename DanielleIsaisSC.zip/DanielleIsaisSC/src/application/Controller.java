package application;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.util.Duration;

public class Controller {

    @FXML
    private TextField minutesField, secondsField, millisecondsField;

    @FXML
    private Button startButton;

    @FXML
    private Label timerLabel;

    private Timeline timeline;

    private boolean isTimeSet = false;
    private boolean isTimerRunning = false;

    @FXML
    public void initialize() {
        startButton.setDisable(true);
        minutesField.textProperty().addListener((observable, oldValue, newValue) -> checkInputFields());
        secondsField.textProperty().addListener((observable, oldValue, newValue) -> checkInputFields());
        millisecondsField.textProperty().addListener((observable, oldValue, newValue) -> checkInputFields());
    }

    private void checkInputFields() {
        boolean disableStartButton = !isTimeSet || minutesField.getText().isEmpty() || secondsField.getText().isEmpty() || millisecondsField.getText().isEmpty();
        startButton.setDisable(disableStartButton);
    }

    @FXML
    private void setTimer() {
        String minutesStr = minutesField.getText();
        String secondsStr = secondsField.getText();
        String millisecondsStr = millisecondsField.getText();

        // Validate input before parsing
        if (!validateInput(minutesStr, secondsStr, millisecondsStr)) {
            // Show error message (optional)
            timerLabel.setText("Invalid Input: Minutes (0-60), Seconds (0-60), and Milliseconds (0-999)");
            return;
        }

        int minutes = Integer.parseInt(minutesStr);
        int seconds = Integer.parseInt(secondsStr);
        int milliseconds = Integer.parseInt(millisecondsStr);

        timerLabel.setText(String.format("%02d:%02d:%03d", minutes, seconds, milliseconds));
        isTimeSet = true;
        // Check if start button should be enabled
        checkInputFields();
    }

    // Add a new method to validate user input
    private boolean validateInput(String minutesStr, String secondsStr, String millisecondsStr) {
        try {
            int minutes = Integer.parseInt(minutesStr);
            int seconds = Integer.parseInt(secondsStr);
            int milliseconds = Integer.parseInt(millisecondsStr);
            return minutes >= 0 && minutes <= 60 && seconds >= 0 && seconds <= 60 && milliseconds >= 0 && milliseconds <= 999 && !(minutes > 60 && seconds > 60 && milliseconds > 999);
        } catch (NumberFormatException e) {
            // Handle potential parsing errors for non-numeric input
            return false;
        }
    }

    @FXML
    private void startTimer() {
        if (!isTimerRunning) {
            int minutes = Integer.parseInt(minutesField.getText());
            int seconds = Integer.parseInt(secondsField.getText());
            int milliseconds = Integer.parseInt(millisecondsField.getText());
            int totalMilliseconds = minutes * 60000 + seconds * 1000 + milliseconds;
            updateTimerLabel(minutes, seconds, milliseconds);
            
            // Resume the timeline if it's paused
            if (timeline != null) {
                timeline.play();
            } else {
                startCountdown(totalMilliseconds);
            }
            
            isTimerRunning = true;
            startButton.setText("Stop");
        } else {
            if (timeline != null) {
                timeline.pause(); // Pause the timeline instead of stopping it
            }
            isTimerRunning = false;
            startButton.setText("Start");
        }
    }

    private void updateTimerLabel(int minutes, int seconds, int milliseconds) {
        int totalMilliseconds = minutes * 60000 + seconds * 1000 + milliseconds;
        int updatedMinutes = totalMilliseconds / 60000;
        int updatedSeconds = (totalMilliseconds % 60000) / 1000;
        int updatedMilliseconds = totalMilliseconds % 1000;

        // Ensure milliseconds are displayed with three decimal places
        String formattedMilliseconds = String.format("%03d", updatedMilliseconds);
        timerLabel.setText(String.format("%02d:%02d:%s", updatedMinutes, updatedSeconds, formattedMilliseconds));
    }


    private void startCountdown(int totalMilliseconds) {
        final int[] remainingMilliseconds = {totalMilliseconds}; // Use an array to make it effectively final
        timeline = new Timeline(
                new KeyFrame(Duration.millis(1), e -> {
                    remainingMilliseconds[0]--; // Decrement the remaining milliseconds
                    if (remainingMilliseconds[0] >= 0) {
                        int minutes = remainingMilliseconds[0] / 60000;
                        int seconds = (remainingMilliseconds[0] % 60000) / 1000;
                        int milliseconds = remainingMilliseconds[0] % 1000;

                        updateTimerLabel(minutes, seconds, milliseconds);
                    } else {
                        timeline.stop();
                        timerLabel.setText("00:00:000"); // Reset label to 00:00:000 when countdown ends
                    }
                })
        );
        timeline.setCycleCount(totalMilliseconds);
        timeline.play();
    }
}
